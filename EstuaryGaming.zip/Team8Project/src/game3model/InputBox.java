package game3model;

/**
 * 
 * @author Al Cooper, Ryan Gray, Vincent Mangubat, Ryan Wang, Davis Pham
 *
 */
public class InputBox extends Cube {
	// An InputBox is the box that a Cube is being dragged to
}
